/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ex4_6680741;

public class testField {
    /*class Airline implements Comparable<Airline>{
        private String name, code;
        private int aircraft, destinations;
        public int compareTo(Airline other){}
        public boolean equals(Object param){}
    }
    */
    
    
}
